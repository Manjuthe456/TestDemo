package com.jobsonclick.dao;

import java.util.List;

public class TestPaper {
	
	private int testPaperId;
	private String testPaperName;
	private int companyId;
	private List<Question> questions;
	public int getTestPaperId() {
		return testPaperId;
	}
	public void setTestPaperId(int testPaperId) {
		this.testPaperId = testPaperId;
	}
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public List<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}
	public String getTestPaperName() {
		return testPaperName;
	}
	public void setTestPaperName(String testPaperName) {
		this.testPaperName = testPaperName;
	}
	
	

}
	