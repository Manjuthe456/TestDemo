package com.jobsonclick.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jobsonclick.dao.Candidate;
import com.jobsonclick.dao.Company;
import com.jobsonclick.utils.DBUtils;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(urlPatterns = {"/Login","/Logout","/ChangePassword"})
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private Company company;
	private Candidate candidate;

    public LoginServlet() {
    	this.company = new Company();
    	this.candidate = new Candidate();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		HttpSession session=request.getSession();
		if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/Logout")) {
			session.invalidate();
			response.sendRedirect("index.jsp");
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		String role=request.getParameter("role");
		
		// Change Password candidate and company
		if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ChangePassword")) {
			System.out.println("in change password servlet");
			String newpassword = request.getParameter("newpassword");
			String oldpassword = request.getParameter("oldpassword");
			String reenterpassword = request.getParameter("reenterpassword");
			String message="";
			System.out.println("old pswd---"+oldpassword+"  "+newpassword);
			if(newpassword.equals(reenterpassword)) {

				if(role.equalsIgnoreCase("company")) {
					int id = (int)session.getAttribute("companyId");											
					message=DBUtils.updateCompanyPassword(id, newpassword)?"Updated Successfully!": "Invalid Credentials!";
				}
				else if(role.equalsIgnoreCase("candidate")) {
					int id = (int)session.getAttribute("candidateId");
					message=DBUtils.candidateChangePassword(id, newpassword)?"Updated Successfully!": "Invalid Credentials!";
				}
				
			}
			else {
				message = "New and Confirm Password mismatch! Please enter again";
			}
			
			request.setAttribute("message", message);
			request.getRequestDispatcher(role+"changepassword.jsp").forward(request, response);
		}
		
		//Login For Admin, company and candidate
		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/Login")) {
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
			// Login for Company
			if( role.equalsIgnoreCase("company")) {
				Company company = DBUtils.fetchCompanyByEmailId(username);
				String message="";
				
				if(company!=null) {
					String enteredPassword = request.getParameter("password");
					if(!company.getPassword().equals(enteredPassword)) {
						message = "Login Failed! Invalid Username or Password";
						request.setAttribute("message", message);
						request.getRequestDispatcher("index.jsp").forward(request, response);
						return;
					}
					if(company.getStatus() == 1) {
						session.setAttribute("companyId", company.getCompanyId());
						request.getRequestDispatcher("/CompanyHome").forward(request, response);
					}
					else if(company.getStatus()== 2) {
						message = "Your registration has been rejected. Please contact Admin!";
						request.setAttribute("message", message);
						request.getRequestDispatcher("companylogin.jsp").forward(request, response);
					}
					else if(company.getStatus() == 0) {
						message = "Your registration request is pending with Admin for approval. Please try later!";
						request.setAttribute("message", message);
						request.getRequestDispatcher("companylogin.jsp").forward(request, response);
					}
						
				}
				else {
					message = "Login Failed! Invalid Username or Password";
					request.setAttribute("message", message);
					request.getRequestDispatcher("companylogin.jsp").forward(request, response);
				}
				
			}
			
			// Login for Candidate
			else if(role.equalsIgnoreCase("candidate")) {
				Candidate candidate = DBUtils.fetchCandidateByEmailId(username);
				String message="";
				
				if(candidate!=null) {
					
					String enteredPassword = request.getParameter("password");
					if(!candidate.getPassword().equals(enteredPassword)) {
						message = "Login Failed! Invalid Username or Password";
						request.setAttribute("message", message);
						request.getRequestDispatcher("index.jsp").forward(request, response);
						return;
					}
					if(candidate.getStatus() == 1) {
						session.setAttribute("candidateId", candidate.getCandidateId());
						request.getRequestDispatcher("/CandidateHome").forward(request, response);
					}
					else if(candidate.getStatus()== 2) {
						message = "Candidate profile locked. Please contact Admin!";
						request.setAttribute("message", message);
						request.getRequestDispatcher("index.jsp").forward(request, response);
					}

				}
				else {
					message = "Login Failed! Invalid Username or Password";
					request.setAttribute("message", message);
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}
				
				
			}
			
			// Login for Admin
			else if(role.equalsIgnoreCase("admin")) {
				
				String message="";
					
				if(username.equalsIgnoreCase("admin@gmail.com")&&password.equals("admin")) {
					
					session.setAttribute("admin",true);
					
					request.setAttribute("username", username);
					request.getRequestDispatcher("/AdminHome").forward(request, response);
				}
				else {
					message = "Login Failed! Invalid Username or Password";
				}
				request.setAttribute("message", message);
				request.getRequestDispatcher("adminlogin.jsp").forward(request, response);
							
			}			
		
	}
		
	}

	private boolean companyChangePassword(int id, String newpassword, String oldpassword) {
		// TODO Auto-generated method stub
		return false;
	}

}
