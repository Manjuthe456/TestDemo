package com.jobsonclick.utils;

import java.util.Properties;

public class SendMail {
	public String d_email ="enlightersJobsOnClock@gmail.com",
			d_password ="changeme@123",
			d_host ="smtp.gmail.com",
			d_port ="456";
	public SendMail(String m_to, String m_subject, String m_text) throws Exception
	{
		Properties pro = new Properties();
		pro.put("mail.smtp.user", d_email);
		pro.put("mail.smtp.host", d_host);
		pro.put("mail.smtp.post", d_port);
		pro.put("mail.smt.starttls.enable","true");
		pro.put("mail.smtp.auth", "true");
		//pro.put("mail.smtp.debug","true");
		pro.put("mail.smtp.socketFactory.port","d_port");
		pro.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
		pro.put("mail.smtp.socketFactory.fallback","false");
		
		SecurityManager security = System.getSecurityManager();

	}

}
