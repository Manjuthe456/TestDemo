package com.jobsonclick.dao;

public class Company {
   private int companyId;
   private String name;
   private String address;
   private String email;
   private String phoneNo;
   private String hrName;
   private String hrEmail;
   private String password;
   private String description;
   private int status;
public int getCompanyId() {
	return companyId;
}
public void setCompanyId(int companyId) {
	this.companyId = companyId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}
public String getHrName() {
	return hrName;
}
public void setHrName(String hrName) {
	this.hrName = hrName;
}
public String getHrEmail() {
	return hrEmail;
}
public void setHrEmail(String hrEmail) {
	this.hrEmail = hrEmail;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}

}
