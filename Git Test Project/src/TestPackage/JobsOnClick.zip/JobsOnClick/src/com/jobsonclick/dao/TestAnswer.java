package com.jobsonclick.dao;

import java.io.InputStream;

public class TestAnswer {
	
	private int testPaperId;
	private String answer;
	private int companyId;
	private int questionId;
	private int candidateId;
	private int openingId;
	 private InputStream answerFile;
	 
	public int getTestPaperId() {
		return testPaperId;
	}
	public void setTestPaperId(int testPaperId) {
		this.testPaperId = testPaperId;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public int getCandidateId() {
		return candidateId;
	}
	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}
	public InputStream getAnswerFile() {
		return answerFile;
	}
	public void setAnswerFile(InputStream answerFile) {
		this.answerFile = answerFile;
	}
	public int getOpeningId() {
		return openingId;
	}
	public void setOpeningId(int openingId) {
		this.openingId = openingId;
	}

	
	
	

}
	