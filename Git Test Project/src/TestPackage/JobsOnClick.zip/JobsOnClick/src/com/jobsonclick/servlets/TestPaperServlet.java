
package com.jobsonclick.servlets;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jobsonclick.dao.Candidate;
import com.jobsonclick.dao.Question;
import com.jobsonclick.dao.TestAnswer;
import com.jobsonclick.dao.TestPaper;
import com.jobsonclick.utils.DBUtils;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet(urlPatterns = { "/AddTestPaper", "/AddQuestionToTP", "/SubmitTestPaper", "/DownloadCode"
 })
public class TestPaperServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public TestPaperServlet() {

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		// ViewCompanies Page
		if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/AddTestPaper")) {
			HttpSession session=request.getSession();

			String testPaperName = request.getParameter("testName");
			if(session.getAttribute("companyId") == null) {
				request.setAttribute("message", "User session expired. Please login again");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			int companyId = (int)session.getAttribute("companyId");
			
			TestPaper paper = new TestPaper();
			paper.setCompanyId(companyId);
			paper.setTestPaperName(testPaperName);
			int testPaperId = DBUtils.createTestPaper(paper);
//			if(!isError) {
//				request.setAttribute("message", "Candidate Created successfully");
//			}
			paper = DBUtils.getTestPaperById(testPaperId);
			request.setAttribute("testPaperId", paper.getTestPaperId());

			request.getRequestDispatcher("companyaddquestions.jsp").forward(request, response);
		}

		// ViewCompany Page
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/AddQuestionToTP")) {
			HttpSession session=request.getSession();

			if(session.getAttribute("companyId") == null) {
				request.setAttribute("message", "User session expired. Please login again");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			int companyId = (int)session.getAttribute("companyId");
			int testPaperId = Integer.parseInt(request.getParameter("testPaperId"));
			int type = Integer.parseInt(request.getParameter("testPaperType"));
			boolean isCodeQuestion = Boolean.valueOf(request.getParameter("fileType"));
			Question question = new Question();
			String option1 = request.getParameter("option1");
			String option2 = request.getParameter("option2");
			String option3 = request.getParameter("option3");
			String option4 = request.getParameter("option4");
			
			String answer = request.getParameter("correctAnswer");
			String objQuestion = request.getParameter("objectiveQuestion");
			String subQuestion = request.getParameter("subjectiveQuestion");
			
			question.setQuestionType(type);
			question.setCompanyId(companyId);
			question.setOption1(option1);
			question.setOption2(option2);
			question.setOption3(option3);
			question.setOption4(option4);
			question.setQuestion(objQuestion);
			question.setCodeQuestion(isCodeQuestion);
			
			question.setAnswer(answer);
			question.setSubjectiveQuestion(subQuestion);
			int questionId = DBUtils.createTestQuestion(question);
			request.setAttribute("testPaperId", testPaperId);
			if(questionId == -1) {
				String message = "Failed to create the question. Please try again";
				
				request.setAttribute("message", message);
				request.getRequestDispatcher("companyaddquestions.jsp").forward(request, response);
				return;
			}

				question = DBUtils.getQuestionByQuestionId(questionId);
			
			boolean isSuccess = DBUtils.assignQuestionsToTestPaper(testPaperId, question.getQuestionId(), companyId);
			if(!isSuccess) {
				String message = "Failed to assign the question to test paper. Please try again";
				
				request.setAttribute("message", message);
				request.getRequestDispatcher("companyaddquestions.jsp").forward(request, response);
			}
			
			request.getRequestDispatcher("companyaddquestions.jsp").forward(request, response);
		}

		// DeactivateCompany Page
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/SubmitTestPaper")) {

			int companyId = Integer.parseInt(request.getParameter("companyId"));
			DBUtils.deactivateCompany(companyId);

			request.getRequestDispatcher("/ViewAdminCompany").forward(request, response);
		}
		
		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/DownloadCode")) {
			
			ServletContext context = getServletContext();
			System.out.println("in downloadCode context-"+context);
			//Blob blob;
			int candidateId= Integer.parseInt(request.getParameter("candidateId"));
			int tpId = Integer.parseInt(request.getParameter("tpId"));
			int questionId = Integer.parseInt(request.getParameter("questionId"));
			int testPaperId = Integer.parseInt(request.getParameter("tpId"));
			int jobId = Integer.parseInt(request.getParameter("jobId"));
			
			TestAnswer answer = DBUtils.getTestPaperAnwserByQuestionId( questionId,  testPaperId,  candidateId,  jobId);
			InputStream inputStream = answer.getAnswerFile();
			Candidate candidate = DBUtils.getCandidateById(Integer.parseInt(request.getParameter("candidateId")));
			String fileName = candidate.getName()+"-CodeFile.zip";
			
			// sets MIME type for the file download
            String mimeType = context.getMimeType(fileName);
            
         
            if (mimeType == null) {        
                mimeType = "application/octet-stream";
            }
			
            int fileLength = inputStream.available();
          
            // set content properties and header attributes for the response
            response.setContentType(mimeType);
            response.setContentLength(fileLength);
            String headerKey = "Content-Disposition";
            String headerValue = String.format("attachment; filename=\"%s\"", fileName);
            response.setHeader(headerKey, headerValue);
			
            // writes the file to the client
            OutputStream outStream = response.getOutputStream();
             
            byte[] buffer = new byte[300 * 1024];
            
            int bytesRead = -1;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, bytesRead);
            }
             
            inputStream.close();
            outStream.close(); 
			
           request.getRequestDispatcher("companyviewtestresult.jsp?jobId="+jobId+"&candidateId="+candidateId).forward(request, response);

		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
