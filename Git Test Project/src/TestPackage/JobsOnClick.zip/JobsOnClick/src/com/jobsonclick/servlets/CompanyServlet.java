package com.jobsonclick.servlets;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jobsonclick.dao.Candidate;
import com.jobsonclick.dao.CandidateApplication;
import com.jobsonclick.dao.Company;
import com.jobsonclick.dao.JobOpening;
import com.jobsonclick.utils.DBUtils;


@WebServlet(urlPatterns= {"/AddJob","/CreateJob","/DeactivateJob","/ViewJobs","/EditJob","/SearchCandidates",
		"/CompanyHome","/ViewCandidate","/UpdateCompanyProfile", "/RegisterCompany","/ViewApplications",
		"/ApproveApplication","/RejectApplication","/ApplicationSendMessage","/DownloadResume", "/TestImage","/TestImageToFile"})
@MultipartConfig
public class CompanyServlet extends HttpServlet{

	
	public CompanyServlet() {

	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		if(session.getAttribute("companyId") == null) {
			request.setAttribute("message", "User session expired. Please login again");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		int companyId = (int)session.getAttribute("companyId");
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		/*
		if(session.getAttribute("companyId")==null) {
			request.getRequestDispatcher("Logout").forward(request, response);
		}
		*/
		if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/AddJob")) {
			request.getRequestDispatcher("companyaddjob.jsp").forward(request, response);
		}
		
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewJobs")) {
			System.out.println("In View Jobs!!!"+companyId);
			String type = request.getParameter("type");
			//int companyId = (int)session.getAttribute("companyId");

			request.setAttribute("type", type);
			request.getRequestDispatcher("companyviewopenings.jsp").forward(request, response);
		}
		
		/*
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewJob")) {
			int jobId = Integer.parseInt(request.getParameter("jobId"));
			Jobs job= jobsDao.getJob(jobId);
			request.setAttribute("job", job);
					
			request.getRequestDispatcher("viewjob.jsp").forward(request, response);
		}
		*/
		
		// Edit Job Opening page
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/EditJob")) {
			int jobId = Integer.parseInt(request.getParameter("jobId"));
			JobOpening job= DBUtils.getJob(jobId);
			request.setAttribute("job", job);		
			System.out.println("In EditJob Servlet...");
			System.out.println("type---"+request.getParameter("type"));
			request.getRequestDispatcher("editjob.jsp").forward(request, response);
		}
		
		// Company Home Page
		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/CompanyHome")) {
			System.out.println("in company home");
			//int companyId = (int)session.getAttribute("companyId");
			Company company = DBUtils.fetchCompany(companyId);
	//undo 		
			int applicationCount = DBUtils.fetchAllCandidateApplicationById(companyId).size();
			int candidateCount = DBUtils.fetchAllCandidates(true).size();
			int jobCount = DBUtils.totalCompanyJobCounts(companyId);
			
			
			session.setAttribute("company", company);			
			request.setAttribute("applicationCount", applicationCount);
			request.setAttribute("candidateCount", candidateCount);
			request.setAttribute("jobCount", jobCount);
			
			request.getRequestDispatcher("companyhomepage.jsp").forward(request, response);
		}
		
		// View Candidate
		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewCandidate")) {
			int candidateId = Integer.parseInt(request.getParameter("candidateId"));
			
			Candidate candidate = DBUtils.fetchCandidate(candidateId);
			request.setAttribute("candidate", candidate);
			request.getRequestDispatcher("viewcandidate.jsp").forward(request, response);
		}
		
		//View Applications
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewApplications")) {
			Map<Integer, List<CandidateApplication>> candidateApplications = new HashMap<>();
			List<JobOpening> jobsList= DBUtils.fetchAllJobOpeningByCompanyId(companyId, true);
	
			for(JobOpening opening: jobsList) {
				List<CandidateApplication> applicationList = DBUtils.fetchAllCandidateApplicationByJobOpening(opening.getJobOpeningId());
				if(applicationList.size() != 0) {
					candidateApplications.put(opening.getJobOpeningId(), applicationList);
				}
			}
			
			request.setAttribute("jobsList", jobsList);
			request.setAttribute("candidateApplications", candidateApplications);
			request.getRequestDispatcher("companyviewapplications.jsp").forward(request, response);
		}
		
		// Approve Application
		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ApproveApplication")) {
			int jobId = Integer.parseInt(request.getParameter("jobId"));
			int candidateId = Integer.parseInt(request.getParameter("candidateId"));
//TODO			applicationDao.approveApplication(jobId, candidateId);
			DBUtils.updateCandidateOpeningStatusByCandidateId(candidateId, jobId, "Selected");
			request.setAttribute("messageTo", request.getParameter("candidateEmail"));
			request.setAttribute("subject", "JobId: "+jobId+"- "+request.getParameter("jobTitle"));
			
			// New message servlet and then send to ApplicationSendMessage (button action), then come back to viewApplications page
			request.getRequestDispatcher("/ViewApplications?role=company").forward(request, response);
		}
		
		// Reject Application
		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/RejectApplication")) {
			int jobId = Integer.parseInt(request.getParameter("jobId"));
			int candidateId = Integer.parseInt(request.getParameter("candidateId"));
			DBUtils.updateCandidateOpeningStatusByCandidateId(candidateId, jobId, "Rejected");

//			applicationDao.rejectApplication(jobId, candidateId);
			request.getRequestDispatcher("/ViewApplications").forward(request, response);
		}
		
		// Download Resume
		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/DownloadResume")) {
			
			ServletContext context = getServletContext();
			System.out.println("in downloadResume context-"+context);
			//Blob blob;
			int candidateId= Integer.parseInt(request.getParameter("candidateId"));
			InputStream inputStream = DBUtils.fetchCandidate(candidateId).getResume();
			Candidate candidate = DBUtils.getCandidateById(Integer.parseInt(request.getParameter("candidateId")));
			String fileName = candidate.getName()+"resume.doc";
			
			// sets MIME type for the file download
            String mimeType = context.getMimeType(fileName);
            
         
            if (mimeType == null) {        
                mimeType = "application/octet-stream";
            }
 			
	/*			//blob = new SerialBlob(resumeArray);
				inputStream = new ByteArrayInputStream(resumeArray);*/
				
			
            int fileLength = inputStream.available();
          
            // set content properties and header attributes for the response
            response.setContentType(mimeType);
            response.setContentLength(fileLength);
            String headerKey = "Content-Disposition";
            String headerValue = String.format("attachment; filename=\"%s\"", fileName);
            response.setHeader(headerKey, headerValue);
			
            // writes the file to the client
            OutputStream outStream = response.getOutputStream();
             
            byte[] buffer = new byte[300 * 1024];
            
            int bytesRead = -1;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, bytesRead);
            }
             
            inputStream.close();
            outStream.close(); 
			Map<Integer, List<CandidateApplication>> candidateApplications = new HashMap<>();
            List<JobOpening> jobsList= DBUtils.fetchAllJobOpeningByCompanyId(companyId, true);
        	
			for(JobOpening opening: jobsList) {
				List<CandidateApplication> applicationList = DBUtils.fetchAllCandidateApplicationByJobOpening(opening.getJobOpeningId());
				if(applicationList.size() != 0) {
					candidateApplications.put(opening.getJobOpeningId(), applicationList);
				}
			}
			
			request.setAttribute("jobsList", jobsList);
			request.setAttribute("candidateApplications", candidateApplications);
           request.getRequestDispatcher("companyviewapplications.jsp").forward(request, response);
            /*
			String appPath = context.getRealPath("/");
			File file = new File(appPath+"images\\test\\logo.jpg");
			byte[] bFile = companyDao.testDownloadImage();
			
			OutputStream os = new FileOutputStream(file);
			
			os.write(bFile);
			
			System.out.println("File inserted!");
			os.close();
			*/
		}
		
		// Deactivate Job
		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/DeactivateJob")) {
			System.out.println("in deactivate job servlet----");
			boolean isNotError = DBUtils.deactivateJobOpening(Integer.parseInt(request.getParameter("jobId")));
			
			String message = "Successfully deactivated the Job Opening";
			if(!isNotError) {
				message = "Error Occurred, while DeActivating Job!";
			}
			request.setAttribute("message", message);		
			request.getRequestDispatcher("companyviewopenings.jsp").forward(request, response);
		}
		
		/*
		else if (request.getRequestURI().equalsIgnoreCase("/Jobs_On_Click/ViewMessages")) {
			int companyId = (int)session.getAttribute("companyId");
			String type = request.getParameter("type");
			List<Message> messageList=null;
			
			if(type.equalsIgnoreCase("inbox")) {
				messageList= messageDao.getAllMessagesInbox(companyId,"company");
			}
			else if(type.equalsIgnoreCase("outbox")) {
				messageList= messageDao.getAllMessagesOutbox(companyId,"company");
			}
			
			request.setAttribute("messageList", messageList);
			request.getRequestDispatcher("viewmessages.jsp").forward(request, response);
		}
		
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewMessage")) {
			int messageId = Integer.parseInt(request.getParameter("messageId"));
			Message message = messageDao.getMessage(messageId);
			request.setAttribute("message", message);	
			request.getRequestDispatcher("viewmessage.jsp").forward(request, response);
		}
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/NewMessage")) {
			int companyId = (int)session.getAttribute("companyId");
			Company company = companyDao.getCompany(companyId);
			request.setAttribute("companyEmail", company.getCompanyEmail());
			request.getRequestDispatcher("sendmessage.jsp").forward(request, response);
		}
		*/
		
	}

	// ----------------------------------------------------------------------------------------------------------------------------
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		
		
		// Save update Job
		if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/CreateJob")) {
			System.out.println("saving!!!");
			
			/*
			Date reqDate = new Date();
			String finalDateString=null;
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date finalDate=null;
			// convert incoming String dateOfPosting to Date type
			try {
				finalDateString = format.format(reqDate);
				finalDate = format.parse(finalDateString);
				
			} catch (ParseException e) {
				e.printStackTrace();
			}
			*/
			if(session.getAttribute("companyId") == null) {
				request.setAttribute("message", "User session expired. Please login again");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			int companyId = (int)session.getAttribute("companyId");

			

			JobOpening opening = new JobOpening();
			opening.setCompanyId(companyId);
			opening.setJobExperience(request.getParameter("experienceRequired"));
			opening.setJobRequirement(request.getParameter("jobSkills"));
			opening.setJobTitle(request.getParameter("jobTitle"));
			opening.setLocation(request.getParameter("jobLocation"));
			opening.setMode(request.getParameter("jobMode"));
			opening.setTestPaperId(Integer.parseInt(request.getParameter("testPaper")));
			opening.setStatus("Open");
			opening.setSalaryRange(request.getParameter("salary"));

			boolean isNotError = DBUtils.createNewJobOpening(opening);
			
			if(isNotError) {
				request.setAttribute("message", "Job saved successfully!");												
			}
			else {
				request.setAttribute("message", "Error Occurred, while saving Job Opening!");
			}
			
			if(request.getParameter("page").equalsIgnoreCase("add"))
				request.getRequestDispatcher("companyaddjob.jsp").forward(request, response);
			else if(request.getParameter("page").equalsIgnoreCase("edit")) {
				// request.setAttribute("companyId",);				
				request.getRequestDispatcher("/EditJob?type=active").forward(request, response);
			}
		} else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/EditJob")) {
			
			
		}

		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/SearchCandidates")) {
			List<Candidate> candidateList =DBUtils.searchCandidatesBySkills(request.getParameter("skills"));
			
			request.setAttribute("candidateList", candidateList);
			request.getRequestDispatcher("companysearchcandidates.jsp?searched=true").forward(request, response);
		}
		
		
		// RegisterCompany
		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/RegisterCompany")) {
			
			String email = request.getParameter("companyEmail");
			if(DBUtils.checkCompanyExists(email))
			{
				request.setAttribute("message", "Sorry, Email is already registered!");
				request.getRequestDispatcher("companyregistration.jsp").forward(request, response);
				return;
			}
			
			Company company = new Company();
			company.setAddress(request.getParameter("companyName"));
			company.setEmail(request.getParameter("companyEmail"));
			company.setHrEmail(request.getParameter("hrEmail"));
			company.setHrName(request.getParameter("hrName"));
			company.setName(request.getParameter("companyName"));
			company.setPhoneNo(request.getParameter("phoneNo"));
			company.setPassword(request.getParameter("companyPassword"));
			company.setDescription(request.getParameter("companyDescription"));
			
			
			boolean isNotError = DBUtils.createNewCompany(company);
			
			if(!isNotError) {
				request.setAttribute("message", "Error registering the new company. Please retry");
			} else {
				request.setAttribute("message", "Successfully registered new company. Please wait for approval from Admin ");
			}
			
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		
		// Company Approve Send Application Message
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ApplicationSendMessage")) {
//			Message message = new Message(
//					request.getParameter("messageFrom"),
//					request.getParameter("messageTo"),
//					request.getParameter("subject"),
//					request.getParameter("body"),
//					new java.sql.Date(new Date().getTime()),
//					true,
//					false);
//			boolean isNotError = messageDao.sendMessage(message);
//
//			if(isNotError) {
//				request.setAttribute("message", "Message sent successfully!");												
//			}
//			else {
//				request.setAttribute("message", "message sending failed!");
//			}
//
//			request.getRequestDispatcher("/ViewApplications").forward(request, response);
		}
		
		// UpdateCompanyProfile
		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/UpdateCompanyProfile")) {
			// company object is already stored in session

			if(session.getAttribute("companyId") == null) {
				request.setAttribute("message", "User session expired. Please login again");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			int companyId = (int)session.getAttribute("companyId");
			Company company = DBUtils.getCompanyById(companyId);
			if(company == null) {
				String message = "Unable to fetch the profile for this company id. Please login again " + companyId;
				request.setAttribute("message", message);
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			
			company.setHrEmail(request.getParameter("hrEmail"));
			company.setHrName(request.getParameter("hrName"));
			company.setName(request.getParameter("companyName") );
			company.setPhoneNo(request.getParameter("phoneNo"));
			company.setPassword(request.getParameter("companyPassword"));
			company.setDescription(request.getParameter("companyDescription"));
			
			
			boolean isNotError = DBUtils.updateCompany(company);
			
			String message = isNotError?"Profile Updated successfully":"Error while updating profile";
			request.setAttribute("message", message);

			request.getRequestDispatcher("companyupdateprofile.jsp").forward(request, response);
		}
		else if(request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ChangePassword")) {
			// company object is already stored in session

			if(session.getAttribute("companyId") == null) {
				request.setAttribute("message", "User session expired. Please login again");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			int companyId = (int)session.getAttribute("companyId");
			String password = request.getParameter("newpassword");
			
			boolean isNotError = DBUtils.updateCompanyPassword(companyId, password);
			
			String message = isNotError?"Profile Updated successfully":"Error while updating profile";
			request.setAttribute("message", message);

			request.getRequestDispatcher("companyupdateprofile.jsp").forward(request, response);
		}
		
		// ***************************************Get calls **********************************************************
		
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewJobs")) {			
			doGet(request,response);
		}
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/EditJob")) {			
			doGet(request,response);
		}
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewApplications")) {			
			doGet(request,response);
		}
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/CompanyHome")) {			
			doGet(request,response);
		}
		
	}

}
