package com.jobsonclick.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobsonclick.dao.Candidate;
import com.jobsonclick.dao.Company;
import com.jobsonclick.dao.JobOpening;
import com.jobsonclick.utils.DBUtils;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet(urlPatterns = { "/ViewAdminCompanies", "/ViewAdminCompany", "/ViewAdminCandidates", "/AdminHome",
		"/ApproveCompany", "/RejectCompany", "/ViewApprovals", "/DeactivateCompany", "/ViewAdminJobs" })
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AdminServlet() {

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

		// ViewCompanies Page
		if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewAdminCompanies")) {

			List<Company> companyList = DBUtils.fetchAllCompany(false);
			request.setAttribute("companyList", companyList);

			request.getRequestDispatcher("adminviewcompanies.jsp").forward(request, response);
		}

		// ViewCompany Page
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewAdminCompany")) {

			int companyId = Integer.parseInt(request.getParameter("companyId"));
			boolean company = DBUtils.activateCompany(companyId);
			request.setAttribute("company", company);

			request.getRequestDispatcher("adminviewcompany.jsp").forward(request, response);
		}

		// DeactivateCompany Page
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/DeactivateCompany")) {

			int companyId = Integer.parseInt(request.getParameter("companyId"));
			DBUtils.deactivateCompany(companyId);

			request.getRequestDispatcher("/ViewAdminCompany").forward(request, response);
		}

		// View Approvals
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewApprovals")) {
			List<Company> companies = DBUtils.fetchAllCompaniesToApprove();
			if (getServletContext() == null) {
				request.setAttribute("message", "No Company Approval Requests");
			}
			request.setAttribute("companyList", companies);
			request.getRequestDispatcher("admincompanyapplications.jsp").forward(request, response);
		}

		// Approve Company
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ApproveCompany")) {
			int companyId = Integer.parseInt(request.getParameter("companyId"));
			DBUtils.activateCompany(companyId);// approveRejectCompany(companyId, "approved");
			request.getRequestDispatcher("/ViewApprovals").forward(request, response);
		}

		// Reject Company
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/RejectCompany")) {
			int companyId = Integer.parseInt(request.getParameter("companyId"));
			DBUtils.deactivateCompany(companyId);
			request.getRequestDispatcher("/ViewApprovals").forward(request, response);
		}

		// View Candidates
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewAdminCandidates")) {

			List<Candidate> candidateList = DBUtils.fetchAllCandidates(false);
			request.setAttribute("candidateList", candidateList);
			request.getRequestDispatcher("adminviewcandidates.jsp").forward(request, response);
		}

		// Admin Home
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/AdminHome")) {

//			int jobCount = DBUtils.checkJobOpeningDAO(getServletInfo());

//TODO: getting company registatrion request
//			int applicationCount = DBUtils.companyRegistrationRequests();

			request.setAttribute("jobCount", DBUtils.fetchAllActiveJobOpening().size());
			request.setAttribute("companyCount", DBUtils.fetchAllCompany(true).size());
			request.setAttribute("applicationCount", DBUtils.fetchAllCandidateApplications().size());

			request.getRequestDispatcher("adminhomepage.jsp").forward(request, response);
		}

		// View Jobs
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/ViewAdminJobs")) {

			List<JobOpening> jobList = DBUtils.fetchAllJobOpening();
			request.setAttribute("jobList", jobList);
			request.getRequestDispatcher("adminviewjobs.jsp").forward(request, response);
		}

	}

// ----------------------------------------------------------------------------------------------------------------------------

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
