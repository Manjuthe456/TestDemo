package com.jobsonclick.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.jobsonclick.dao.Candidate;
import com.jobsonclick.dao.CandidateApplication;
import com.jobsonclick.dao.Company;
import com.jobsonclick.dao.JobOpening;
import com.jobsonclick.dao.Question;
import com.jobsonclick.dao.TestAnswer;
import com.jobsonclick.dao.TestPaper;
import com.jobsonclick.db.connection.DBConnectionProvider;

public class DBUtils {

	// ADMIN Operations
	public static synchronized List<Candidate> fetchAllCandidates(boolean onlyActive) {
		PreparedStatement statement = null;
		ResultSet result = null;
		List<Candidate> Candidatelist = new ArrayList<Candidate>();
		String sql = "select * from candidate";
		if (onlyActive) {
			sql = "select * from candidate where status =1";
		}
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			result = statement.executeQuery();

			while (result.next()) {
				Candidate cd = new Candidate();
				cd.setCandidateId(result.getInt("candidate_id"));
				cd.setName(result.getString("name"));
				cd.setPhoneNo(result.getString("phone_no"));
				cd.setEmail(result.getString("email"));
				cd.setAddress(result.getString("address"));
				cd.setGender(result.getString("gender"));
				cd.setDob(result.getString("dob"));
				cd.setQualification(result.getString("qualification"));
				cd.setYearOfExperience(result.getString("year_of_experience"));
				cd.setPhoto(result.getBinaryStream("photo"));
				cd.setResume(result.getBinaryStream("resume"));
				cd.setSkills(result.getString("skills"));

				Candidatelist.add(cd);

			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return Candidatelist;
	}

	public static synchronized List<Candidate> searchCandidatesBySkills(String skill) {
		PreparedStatement statement = null;
		ResultSet result = null;
		List<Candidate> Candidatelist = new ArrayList<Candidate>();
		String sql = "select * from candidate where status=1 and skills like '%?%'";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, skill);
			result = statement.executeQuery();

			while (result.next()) {
				Candidate cd = new Candidate();
				cd.setCandidateId(result.getInt("candidate_id"));
				cd.setName(result.getString("name"));
				cd.setPhoneNo(result.getString("phone_no"));
				cd.setEmail(result.getString("email"));
				cd.setAddress(result.getString("address"));
				cd.setGender(result.getString("gender"));
				cd.setDob(result.getString("dob"));
				cd.setSkills(result.getString("skills"));
				cd.setQualification(result.getString("qualification"));
				cd.setYearOfExperience(result.getString("year_of_experience"));
				cd.setPhoto(result.getBinaryStream("photo"));
				cd.setResume(result.getBinaryStream("resume"));

				Candidatelist.add(cd);

			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return Candidatelist;
	}

	public static synchronized Candidate getCandidateById(int candidateId) {
		PreparedStatement statement = null;
		ResultSet result = null;
		String sql = "select * from candidate where candidate_id=?";
		Candidate cd = new Candidate();
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, candidateId);
			result = statement.executeQuery();

			while (result.next()) {

				cd.setCandidateId(result.getInt("candidate_id"));
				cd.setName(result.getString("name"));
				cd.setPhoneNo(result.getString("phone_no"));
				cd.setEmail(result.getString("email"));
				cd.setAddress(result.getString("address"));
				cd.setGender(result.getString("gender"));
				cd.setDob(result.getString("dob"));
				cd.setQualification(result.getString("qualification"));
				cd.setYearOfExperience(result.getString("year_of_experience"));
				cd.setPhoto(result.getBinaryStream("photo"));
				cd.setResume(result.getBinaryStream("resume"));

			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return cd;
	}

	// CANDIDATE OPENING
	public static synchronized List<CandidateApplication> fetchAllCandidateApplications() {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<CandidateApplication> CandidateOpeninglist = new ArrayList<CandidateApplication>();
		String sql = "select * from candidate_opening";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			results = statement.executeQuery();

			while (results.next()) {
				CandidateApplication cd = new CandidateApplication();
				cd.setCandidateId(results.getInt("candidate_id"));
				cd.setJobOpeningId(results.getInt("job_opening_id"));
				cd.setCandidateOpeningId(results.getInt("candidate_opening_id"));
				// TODO cd.setEmailSend(results.getBoolean("emailsend"));
				// TODO cd.setTestResult(results.getBoolean("test_send"));

				CandidateOpeninglist.add(cd);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return CandidateOpeninglist;
	}

	public static synchronized List<TestPaper> fetchAllTestPapersByCompanyId(int companyId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<TestPaper> testPaperLists = new ArrayList<TestPaper>();
		String sql = "select * from test_paper where company_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, companyId);
			results = statement.executeQuery();

			while (results.next()) {
				TestPaper tp = new TestPaper();
				tp.setCompanyId(results.getInt("company_id"));
				tp.setTestPaperId(results.getInt("test_paper_id"));
				tp.setTestPaperName(results.getString("test_paper_name"));

				testPaperLists.add(tp);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return testPaperLists;
	}

	// candidate id
	public static synchronized List<CandidateApplication> fetchAllCandidateApplicationById(int candidateId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<CandidateApplication> CandidateOpeninglist = new ArrayList<CandidateApplication>();
		String sql = "select * from candidate_opening where candidate_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, candidateId);
			results = statement.executeQuery();

			while (results.next()) {
				CandidateApplication cd = new CandidateApplication();
				cd.setCandidateId(results.getInt("candidate_id"));
				cd.setJobOpeningId(results.getInt("job_opening_id"));
				cd.setCandidateOpeningId(results.getInt("candidate_opening_id"));
				cd.setResult(results.getString("result"));
				cd.setStatus(results.getString("status"));
				// TODO cd.setEmailSend(results.getBoolean("emailsend"));
				// TODO cd.setTestResult(results.getBoolean("test_send"));

				CandidateOpeninglist.add(cd);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return CandidateOpeninglist;
	}

	public static synchronized List<CandidateApplication> fetchAllCandidateApplicationByJobOpening(int jobOpeningId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<CandidateApplication> CandidateOpeninglist = new ArrayList<CandidateApplication>();
		String sql = "select * from candidate_opening where job_opening_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, jobOpeningId);
			results = statement.executeQuery();

			while (results.next()) {
				CandidateApplication cd = new CandidateApplication();
				cd.setCandidateId(results.getInt("candidate_id"));
				cd.setJobOpeningId(results.getInt("job_opening_id"));
				cd.setCandidateOpeningId(results.getInt("candidate_opening_id"));
				cd.setResult(results.getString("result"));

				// TODO cd.setEmailSend(results.getBoolean("emailsend"));
				// TODO cd.setTestResult(results.getBoolean("test_send"));

				CandidateOpeninglist.add(cd);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return CandidateOpeninglist;
	}

	// Company
	public static synchronized List<Company> fetchAllCompany(boolean onlyActive) {
		PreparedStatement statement = null;
		ResultSet result = null;
		List<Company> CompanyList = new ArrayList<Company>();
		String sql = "select * from company";
		if (onlyActive) {
			sql = "select * from company where status=1";
		}
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			ResultSet results = statement.executeQuery();

			while (results.next()) {
				Company cd = new Company();
				cd.setCompanyId(results.getInt("company_id"));
				cd.setName(results.getString("name"));
				cd.setAddress(results.getString("address"));
				cd.setEmail(results.getString("email"));
				cd.setPhoneNo(results.getString("phone_no"));
				cd.setHrName(results.getString("hr_name"));
				cd.setHrEmail(results.getString("hr_email"));
				cd.setDescription(results.getString("description"));
				cd.setStatus(results.getInt("status"));

				CompanyList.add(cd);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return CompanyList;
	}

	public static synchronized List<Company> fetchAllCompaniesToApprove() {
		PreparedStatement statement = null;
		ResultSet result = null;
		List<Company> CompanyList = new ArrayList<Company>();

		String sql = "select * from company where status=0";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			ResultSet results = statement.executeQuery();

			while (results.next()) {
				Company cd = new Company();
				cd.setCompanyId(results.getInt("company_id"));
				cd.setName(results.getString("name"));
				cd.setAddress(results.getString("address"));
				cd.setEmail(results.getString("email"));
				cd.setPhoneNo(results.getString("phone_no"));
				cd.setHrName(results.getString("hr_name"));
				cd.setHrEmail(results.getString("hr_email"));
				cd.setDescription(results.getString("description"));
				cd.setStatus(results.getInt("status"));

				CompanyList.add(cd);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return CompanyList;
	}

	public static synchronized Company getCompanyById(int companyId) {
		PreparedStatement statement = null;
		ResultSet result = null;
		Company cd = null;
		String sql = "select * from company where company_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, companyId);
			ResultSet results = statement.executeQuery();

			while (results.next()) {
				cd = new Company();
				cd.setCompanyId(results.getInt("company_id"));
				cd.setName(results.getString("name"));
				cd.setAddress(results.getString("address"));
				cd.setEmail(results.getString("email"));
				cd.setPhoneNo(results.getString("phone_no"));
				cd.setHrName(results.getString("hr_name"));
				cd.setHrEmail(results.getString("hr_email"));
				cd.setDescription(results.getString("description"));

			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return cd;
	}

	public static synchronized boolean checkCompanyExists(String emailId) {
		PreparedStatement statement = null;
		ResultSet result = null;
		List<Company> CompanyList = new ArrayList<Company>();
		String sql = "select * from company where email=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, emailId);
			ResultSet results = statement.executeQuery();

			while (results.next()) {
				return true;
			}
		} catch (Exception e) {
			return false;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return false;
	}

	// activate company
	public static synchronized boolean activateCompany(int companyId) {
		PreparedStatement statement = null;
		ResultSet result = null;
		String sql = "Update company set status=1 where company_Id=" + companyId;

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.execute();

		} catch (Exception exe) {
			exe.printStackTrace();
			return false;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return true;

	}

	// deactivate company
	public static synchronized boolean deactivateCompany(int companyId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		String sql = "update company set active='deactive' where company_id=" + companyId;

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.execute();
		} catch (Exception exe) {
			return false;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return true;
	}

	// fetch status of Candidate
	public static synchronized String fetchStatus(int candidateId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		String sql = "select status from candidate where candidate_id=" + candidateId;
		String status = "";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			results = statement.executeQuery();
			while (results.next()) {
				status = results.getString("status");
			}

		} catch (Exception exe) {
			return "";

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return status;
	}

	// Candidate Operation
	// fetch candidate with email and password
	public static synchronized boolean checkCandidate(String email) {
		PreparedStatement statement = null;
		ResultSet results = null;
		String sql = "select count(*) As count candidate where email=?";
		boolean flag = false;
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, sql);
			results = statement.executeQuery();

			while (results.next()) {
				if (results.getInt("count") != 0) {
					flag = true;
					System.out.println("TRUE");
				} else {
					flag = false;
					System.out.println("FALSE");
				}

			}
		} catch (Exception exe) {
			System.out.println("Exception!" + exe.toString());
			return true;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return flag;
	}

	// Company Operation
	// fetch candidate with email and password
	public static synchronized boolean checkCompany(String email) {
		PreparedStatement statement = null;
		ResultSet results = null;
		String sql = "select count(*) As count company where email=?";
		boolean flag = false;
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, sql);
			results = statement.executeQuery();

			while (results.next()) {
				if (results.getInt("count") != 0) {
					flag = true;
					System.out.println("TRUE");
				} else {
					flag = false;
					System.out.println("FALSE");
				}

			}
		} catch (Exception exe) {
			System.out.println("Exception!" + exe.toString());
			return true;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return flag;
	}

	// fetch Candidate details
	public static synchronized Candidate fetchCandidate(int candidateId) {
		PreparedStatement statement = null;
		ResultSet result = null;
		Candidate cd = new Candidate();
		String sql = "select * from candidate where candidate_id=?";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, candidateId);
			result = statement.executeQuery();

			while (result.next()) {

				cd.setCandidateId(result.getInt("candidate_id"));
				cd.setName(result.getString("name"));
				cd.setPhoneNo(result.getString("phone_no"));
				cd.setEmail(result.getString("email"));
				cd.setAddress(result.getString("address"));
				cd.setGender(result.getString("gender"));
				cd.setDob(result.getString("dob"));
				cd.setQualification(result.getString("qualification"));
				cd.setYearOfExperience(result.getString("year_of_experience"));
	//			cd.setPhoto(result.getBlob("photo").getBinaryStream());
				cd.setResume(result.getBlob("resume").getBinaryStream());
				cd.setStatus(result.getInt("status"));
				cd.setSkills(result.getString("skills"));

			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return cd;
	}

	public static synchronized Candidate fetchCandidateByEmailId(String emailId) {
		PreparedStatement statement = null;
		ResultSet result = null;
		Candidate cd = null;
		String sql = "select * from candidate where email=?";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, emailId);
			result = statement.executeQuery();

			while (result.next()) {
				cd = new Candidate();
				cd.setCandidateId(result.getInt("candidate_id"));
				cd.setName(result.getString("name"));
				cd.setPhoneNo(result.getString("phone_no"));
				cd.setEmail(result.getString("email"));
				cd.setAddress(result.getString("address"));
				cd.setGender(result.getString("gender"));
				cd.setDob(result.getString("dob"));
				cd.setQualification(result.getString("qualification"));
				cd.setYearOfExperience(result.getString("year_of_experience"));
				cd.setPhoto(result.getBinaryStream("photo"));
				cd.setResume(result.getBinaryStream("resume"));
				cd.setStatus(result.getInt("status"));
				cd.setPassword(result.getString("password"));

			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return cd;
	}

	// fetch Company details
	public static synchronized Company fetchCompany(int companyId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		Company com = new Company();
		String sql = "select * from company where company_id=" + companyId;

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			results = statement.executeQuery();

			while (results.next()) {
				com.setCompanyId(results.getInt("companyid"));
				com.setName(results.getString("name"));
				com.setAddress(results.getString("address"));
				com.setEmail(results.getString("email"));
				com.setPhoneNo(results.getString("phoneno"));
				com.setHrName(results.getString("hr_name"));
				com.setHrEmail(results.getString("hr_email"));
				com.setStatus(results.getInt("status"));

			}
		} catch (Exception e) {
			return null;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return com;

	}

	public static synchronized Company fetchCompanyByEmailId(String emailId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		Company com = null;
		String sql = "select * from company where email=? and status=1";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, emailId);
			results = statement.executeQuery();

			while (results.next()) {
				com = new Company();
				com.setCompanyId(results.getInt("company_id"));
				com.setName(results.getString("name"));
				com.setAddress(results.getString("address"));
				com.setEmail(results.getString("email"));
				com.setPhoneNo(results.getString("phone_no"));
				com.setHrName(results.getString("hr_name"));
				com.setHrEmail(results.getString("hr_email"));
				com.setStatus(results.getInt("status"));
				com.setDescription(results.getString("description"));
				com.setPassword(results.getString("password"));

			}
		} catch (Exception e) {
			return null;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return com;

	}

	// add Candidate
	public static synchronized boolean createNewCandidate(Candidate candidate) {
		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "insert into candidate (name, phone_no, email, address, gender, dob, qualification, year_of_experience, photo, resume, status, skills, password) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);

			statement.setString(1, candidate.getName());
			statement.setString(2, candidate.getPhoneNo());
			statement.setString(3, candidate.getEmail());
			statement.setString(4, candidate.getAddress());
			statement.setString(5, candidate.getGender());
			statement.setString(6, candidate.getDob());
			statement.setString(7, candidate.getQualification());
			statement.setString(8, candidate.getYearOfExperience());
			statement.setBlob(9, candidate.getPhoto());
			statement.setBlob(10, candidate.getResume());
			statement.setInt(11, 1);
			statement.setString(12, candidate.getSkills());
			statement.setString(13, candidate.getPassword());
			statement.execute();

		} catch (Exception exe) {
			return false;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return true;
	}

	public static synchronized boolean updateCandidate(Candidate candidate) {
		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "update candidate set phone_no=?, address=?, qualification=?, year_of_experience=?, photo=?, resume=?, skills=? where candidate_id=?";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);

			statement.setString(1, candidate.getPhoneNo());
			statement.setString(2, candidate.getAddress());
			statement.setString(3, candidate.getQualification());
			statement.setString(4, candidate.getYearOfExperience());
			statement.setBinaryStream(5, candidate.getPhoto());
			statement.setBinaryStream(6, candidate.getResume());
			statement.setString(7, candidate.getSkills());
			statement.setInt(8, candidate.getCandidateId());
			statement.execute();
		} catch (Exception exe) {
			return false;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return true;
	}

	// add Company
	public static synchronized boolean createNewCompany(Company Company) {
		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "insert into company ( name, address, email, phone_no, hr_name, hr_email, password, description, status) values (?,?,?,?,?,?,?,?,?)";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, Company.getName());
			statement.setString(2, Company.getAddress());
			statement.setString(3, Company.getEmail());
			statement.setString(4, Company.getPhoneNo());
			statement.setString(5, Company.getHrName());
			statement.setString(6, Company.getHrEmail());
			statement.setString(7, Company.getPassword());
			statement.setString(8, Company.getDescription());
			statement.setInt(9, 0);
			statement.execute();
		} catch (Exception exe) {
			return false;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return true;
	}

	public static synchronized boolean updateCompany(Company Company) {
		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "update company set address=?, phone_no=?, hr_name=?, hr_email=?, description=? where company_id=?";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, Company.getAddress());
			statement.setString(2, Company.getPhoneNo());
			statement.setString(3, Company.getHrName());
			statement.setString(4, Company.getHrEmail());
			statement.setString(5, Company.getDescription());
			statement.setInt(6, Company.getCompanyId());
			statement.execute();
		} catch (Exception exe) {
			return false;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return true;
	}

	public static synchronized boolean updateCompanyPassword(int companyId, String password) {
		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "update company password=? where company_id=?";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);

			statement.setString(1, password);
			statement.setInt(2, companyId);
			statement.execute();
		} catch (Exception exe) {
			return false;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return true;
	}

	// JobOpening
	public static synchronized List<JobOpening> fetchAllJobOpening() {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<JobOpening> JobOpeninglist = new ArrayList<JobOpening>();
		String sql = "select * from job_opening";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			results = statement.executeQuery();

			while (results.next()) {
				JobOpening job = new JobOpening();
				job.setJobOpeningId(results.getInt("job_opening_id"));
				job.setCompanyId(results.getInt("company_id"));
				job.setJobRequirement(results.getString("job_requirement"));
				job.setJobExperience(results.getString("job_exp"));
				job.setLocation(results.getString("location"));
				job.setMode(results.getString("mode"));
				job.setStatus(results.getString("status"));
				job.setJobTitle(results.getString("job_title"));
				job.setTestPaperId(results.getInt("test_paper_id"));
				JobOpeninglist.add(job);
			}
		} catch (Exception e) {
			return null;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return JobOpeninglist;

	}

	public static synchronized List<JobOpening> fetchAllActiveJobOpeningsBySkills(String skillSet) {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<JobOpening> JobOpeninglist = new ArrayList<JobOpening>();
		String sql = "select * from job_opening where status=? and job_requirement LIKE CONCAT( '%',?,'%')";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, "Open");
			statement.setString(2, skillSet);
			results = statement.executeQuery();

			while (results.next()) {
				JobOpening job = new JobOpening();
				job.setJobOpeningId(results.getInt("job_opening_id"));
				job.setCompanyId(results.getInt("company_id"));
				job.setJobRequirement(results.getString("job_requirement"));
				job.setJobExperience(results.getString("job_exp"));
				job.setLocation(results.getString("location"));
				job.setMode(results.getString("mode"));
				job.setStatus(results.getString("status"));
				job.setJobTitle(results.getString("job_title"));
				job.setTestPaperId(results.getInt("test_paper_id"));
				JobOpeninglist.add(job);
			}
		} catch (Exception e) {
			return null;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return JobOpeninglist;

	}

	public static synchronized List<JobOpening> fetchAllActiveJobOpening() {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<JobOpening> JobOpeninglist = new ArrayList<JobOpening>();
		String sql = "select * from job_opening where status=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, "Open");
			results = statement.executeQuery();

			while (results.next()) {
				JobOpening job = new JobOpening();
				job.setJobOpeningId(results.getInt("job_opening_id"));
				job.setCompanyId(results.getInt("company_id"));
				job.setJobRequirement(results.getString("job_requirement"));
				job.setJobExperience(results.getString("job_exp"));
				job.setLocation(results.getString("location"));
				job.setMode(results.getString("mode"));
				job.setStatus(results.getString("status"));
				job.setJobTitle(results.getString("job_title"));
				job.setTestPaperId(results.getInt("test_paper_id"));
				JobOpeninglist.add(job);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return JobOpeninglist;

	}

	public static synchronized List<JobOpening> fetchAllJobOpeningByCompanyId(int companyId, boolean onlyActive) {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<JobOpening> JobOpeninglist = new ArrayList<JobOpening>();
		String sql = "select * from job_opening where company_id=?";
		if (onlyActive) {
			sql = "select * from job_opening where company_id=? and status=?";
		}
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, companyId);
			if (onlyActive)
				statement.setString(2, "Open");
			results = statement.executeQuery();

			while (results.next()) {
				JobOpening job = new JobOpening();
				job.setJobOpeningId(results.getInt("job_opening_id"));
				job.setCompanyId(results.getInt("company_id"));
				job.setJobRequirement(results.getString("job_requirement"));
				job.setJobExperience(results.getString("job_exp"));
				job.setLocation(results.getString("location"));
				job.setMode(results.getString("mode"));
				job.setStatus(results.getString("status"));
				job.setJobTitle(results.getString("job_title"));
				job.setTestPaperId(results.getInt("test_paper_id"));
				JobOpeninglist.add(job);
			}
		} catch (Exception e) {
			return null;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return JobOpeninglist;

	}

	// fetch jobOpening details
	public static synchronized JobOpening fetchJobOpening(int jobOpeningId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		JobOpening job = new JobOpening();
		String sql = "select * from job_opening where job_opening_id=?";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, jobOpeningId);
			results = statement.executeQuery();

			while (results.next()) {
				job.setJobOpeningId(results.getInt("job_opening_id"));
				job.setCompanyId(results.getInt("company_id"));
				job.setJobRequirement(results.getString("job_requirement"));
				job.setJobExperience(results.getString("job_exp"));
				job.setLocation(results.getString("location"));
				job.setMode(results.getString("mode"));
				job.setStatus(results.getString("status"));
				job.setJobTitle(results.getString("job_title"));
				job.setTestPaperId(results.getInt("test_paper_id"));

			}
		} catch (Exception e) {
			return null;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return job;

	}

	// add new jobOPening

	public static synchronized boolean createNewJobOpening(JobOpening JobOpening) {
		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "insert into job_opening (company_id, job_exp, job_requirement, location, mode, status, salary, job_title, test_paper_id) values (?,?,?,?,?,?,?,?,?)";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, JobOpening.getCompanyId());
			statement.setString(2, JobOpening.getJobExperience());
			statement.setString(3, JobOpening.getJobRequirement());
			statement.setString(4, JobOpening.getLocation());
			statement.setString(5, JobOpening.getMode());
			statement.setString(6, JobOpening.getStatus());
			statement.setString(7, JobOpening.getSalaryRange());
			statement.setString(8, JobOpening.getJobTitle());
			statement.setInt(9, JobOpening.getTestPaperId());
			statement.execute();
		} catch (Exception e) {
			return false;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return true;
	}
	// JobOpening Operation

	public static synchronized boolean checkJobOpening(String email) {
		PreparedStatement statement = null;
		ResultSet results = null;
		String sql = "select count(*) As count job_opening where email=?";
		boolean flag = false;
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, sql);
			results = statement.executeQuery();

			while (results.next()) {
				if (results.getInt("count") != 0) {
					flag = true;
					System.out.println("TRUE");
				} else {
					flag = false;
					System.out.println("FALSE");
				}

			}
		} catch (Exception exe) {
			System.out.println("Exception!" + exe.toString());
			return true;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return flag;
	}

	// CandidateOpening Operation
	// fetch candidate with email and password
	public static synchronized boolean checkCandidateOpening(int candidateId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		String sql = "select count(*) As count candidate_opening where email=?";
		boolean flag = false;
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, sql);
			results = statement.executeQuery();

			while (results.next()) {
				if (results.getInt("count") != 0) {
					flag = true;
					System.out.println("TRUE");
				} else {
					flag = false;
					System.out.println("FALSE");
				}

			}
		} catch (Exception exe) {
			System.out.println("Exception!" + exe.toString());
			return true;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return flag;
	}

	public static synchronized boolean insertCandidateJobApplication(int jobId, int candidateId) {
		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "insert into candidate_opening (job_opening_id, candidate_id, status) values (?,?,?)";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);

			statement.setInt(1, jobId);
			statement.setInt(2, candidateId);
			statement.setString(3, "Applied");

			statement.execute();

		} catch (Exception exe) {
			return false;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return true;
	}

	// public static synchronized List<TestPaper> fetchAllTest() {
	// PreparedStatement statement = null;
	// ResultSet results = null;
	// List<TestPaper> testlist = new ArrayList<TestPaper>();
	//
	// }

	public static int checkJobOpeningDAO(String servletInfo) {

		return 0;
	}

	// companyid
	public static synchronized List<Company> companyId() {
		PreparedStatement statement = null;
		ResultSet result = null;
		List<Company> CompanyList = new ArrayList<Company>();
		String sql = "select * from company where company_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			ResultSet results = statement.executeQuery();

			while (results.next()) {
				Company cd = new Company();
				cd.setCompanyId(results.getInt("company_id"));
				cd.setName(results.getString("name"));
				cd.setAddress(results.getString("address"));
				cd.setEmail(results.getString("email"));
				cd.setPhoneNo(results.getString("phone_no"));
				cd.setHrName(results.getString("hr_name"));
				cd.setHrEmail(results.getString("hr_email"));

				CompanyList.add(cd);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return CompanyList;
	}

	// active jobs
	public static boolean getAllActiveJobOpening(int companyId) {
		PreparedStatement statement = null;
		ResultSet result = null;
		String sql = "Update Company set activejobopening='activejobopening' where company_id=" + companyId;

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.execute();

		} catch (Exception exe) {
			exe.printStackTrace();
			return false;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return true;

	}

	// expired job
	public static List<JobOpening> getAllExpiredJobs(int companyId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<JobOpening> JobOpeninglist = new ArrayList<JobOpening>();
		String sql = "select * from job_opening where company_id=? and status=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, companyId);
			statement.setString(2, "Closed");
			results = statement.executeQuery();

			while (results.next()) {
				JobOpening job = new JobOpening();
				job.setJobOpeningId(results.getInt("job_opening_id"));
				job.setCompanyId(results.getInt("company_id"));
				job.setJobRequirement(results.getString("job_requirement"));
				job.setJobExperience(results.getString("job_exp"));
				job.setLocation(results.getString("location"));
				job.setMode(results.getString("mode"));
				job.setStatus(results.getString("status"));
				job.setJobTitle(results.getString("job_title"));
				JobOpeninglist.add(job);
			}
		} catch (Exception e) {
			return null;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return JobOpeninglist;
	}
	// job

	public static JobOpening getJob(int jobId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		String sql = "select * from job_opening where job_opening_id=?";
		JobOpening jobOpening = new JobOpening();

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, jobId);
			results = statement.executeQuery();

			while (results.next()) {
				jobOpening.setJobOpeningId(results.getInt("job_opening_id"));
				jobOpening.setCompanyId(results.getInt("company_id"));
				jobOpening.setJobRequirement(results.getString("job_requirement"));
				jobOpening.setJobExperience(results.getString("job_exp"));
				jobOpening.setLocation(results.getString("location"));
				jobOpening.setMode(results.getString("mode"));
				jobOpening.setStatus(results.getString("status"));
				jobOpening.setJobTitle(results.getString("job_title"));
				jobOpening.setTestPaperId(results.getInt("test_paper_id"));
			}
		} catch (Exception e) {
			return null;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return jobOpening;

	}

	public static synchronized Candidate totalCandidateCounts(int candidateId) {
		PreparedStatement statement = null;
		ResultSet result = null;
		Candidate cd = new Candidate();
		String sql = "select * from Candidate where totalCandidateCounts=" + candidateId;

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			result = statement.executeQuery();

			while (result.next()) {
				cd.setCandidateId(result.getInt("candidate_id"));
				cd.setName(result.getString("name"));
				cd.setPhoneNo(result.getString("phone_no"));
				cd.setEmail(result.getString("email"));
				cd.setAddress(result.getString("address"));
				cd.setGender(result.getString("gender"));
				cd.setDob(result.getString("dob"));
				cd.setQualification(result.getString("qualification"));
				cd.setYearOfExperience(result.getString("year_of_experience"));
				cd.setPhoto(result.getBinaryStream("photo"));
				cd.setResume(result.getBinaryStream("resume"));

			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, result);
		}
		return cd;

	}

	public static int totalCompanyJobCounts(int companyId) {
		// TODO Auto-generated method stub
		return 0;
	}

	// jobApplicationApplied
	public static synchronized List<CandidateApplication> JobApplicationApplied(int jobId,
			int candidateId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<CandidateApplication> CandidateOpeninglist = new ArrayList<CandidateApplication>();
		String sql = "select * from candidate_opening where job_opening_id=? and candidate_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, jobId);
			statement.setInt(2, candidateId);
			results = statement.executeQuery();

			while (results.next()) {
				CandidateApplication cd = new CandidateApplication();
				cd.setCandidateId(results.getInt("candidate_id"));
				cd.setJobOpeningId(results.getInt("job_opening_id"));
				cd.setCandidateOpeningId(results.getInt("candidate_opening_id"));
				// TODO cd.setEmailSend(results.getBoolean("emailsend"));
				// TODO cd.setTestResult(results.getBoolean("test_send"));

				CandidateOpeninglist.add(cd);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return CandidateOpeninglist;
	}

	// change password company

	public static synchronized boolean companyChangePassword(int company_id, String password) {
		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "update company set password=? where company_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, password);
			statement.setInt(2, company_id);
			statement.execute();
		} catch (Exception exe) {
			return false;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return true;
	}
	// change candidate password

	public static synchronized boolean candidateChangePassword(int candidate_id, String password) {
		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "update candidate set password=? where candidate_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, password);
			statement.setInt(2, candidate_id);
			statement.execute();
		} catch (Exception exe) {
			return false;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return true;
	}

	public static synchronized boolean deactivateJobOpening(int jobId) {
		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "update job_opening set status=? where job_opening_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, "Closed");
			statement.setInt(2, jobId);
			statement.execute();
		} catch (Exception exe) {
			return false;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return true;
	}

	public static synchronized int createTestPaper(TestPaper paper) {

		PreparedStatement statement = null;
		ResultSet results = null;
		int testPaperId = getMaxValue("test_paper_id", "test_paper");

		String sql = "insert into test_paper (company_id, test_paper_name, test_paper_id) values (?,?,?)";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, paper.getCompanyId());
			statement.setString(2, paper.getTestPaperName());
			statement.setInt(3, testPaperId);

			statement.execute();

		} catch (Exception exe) {
			return -1;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return testPaperId;
	}
	
	public static synchronized int createTestQuestion(Question question) {

		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "insert into question (company_id, question_type, option1, option2, option3, option4, answer, sub_question, question_id, obj_question, is_file_question) values (?,?,?,?,?,?,?,?,?,?,?)";
		int questionId = getMaxValue("question_id", "question");

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, question.getCompanyId());
			statement.setInt(2, question.getQuestionType());
			statement.setString(3, question.getOption1());
			statement.setString(4, question.getOption2());
			statement.setString(5, question.getOption3());
			statement.setString(6, question.getOption4());
			statement.setString(7, question.getAnswer());
			statement.setString(8, question.getSubjectiveQuestion());
			statement.setInt(9, questionId);
			statement.setString(10, question.getQuestion());
			statement.setBoolean(11, question.isCodeQuestion());
			statement.execute();

		} catch (Exception exe) {
			return -1;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return questionId;
	}
	
	public static synchronized boolean assignQuestionsToTestPaper(int tpId, int questionId, int companyId) {

		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "insert into test_paper_question (test_paper_id, question_id, company_id) values (?,?,?)";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);

			statement.setInt(1, tpId);
			statement.setInt(2, questionId);
			statement.setInt(3, companyId);
			statement.execute();

		} catch (Exception exe) {
			return false;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return true;
	}
	
	public static synchronized boolean submitTestPaperQuestionAnswer(TestAnswer answers) {

		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "insert into test_paper_answer (test_paper_id, question_id, company_id, answer, candidate_id, opening_id, code_file) values (?,?,?,?,?,?,?)";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);

			statement.setInt(1, answers.getTestPaperId());
			statement.setInt(2, answers.getQuestionId());
			statement.setInt(3, answers.getCompanyId());
			statement.setString(4, answers.getAnswer());
			statement.setInt(5, answers.getCandidateId());
			statement.setInt(6, answers.getOpeningId());
			statement.setBlob(7, answers.getAnswerFile());
			statement.execute();

		} catch (Exception exe) {
			return false;

		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);

		}
		return true;
	}
	
	/*public static synchronized TestPaper getTestPaperByName(String tpName) {
		PreparedStatement statement = null;
		ResultSet results = null;
		TestPaper tp = new TestPaper();

		String sql = "select * from test_paper where test_paper_name=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, tpName);
			results = statement.executeQuery();

			while (results.next()) {
				tp.setTestPaperId(results.getInt("test_paper_id"));
				tp.setCompanyId(results.getInt("company_id"));
				tp.setTestPaperName(results.getString("test_paper_name"));
				// TODO cd.setEmailSend(results.getBoolean("emailsend"));
				// TODO cd.setTestResult(results.getBoolean("test_send"));

			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return tp;
	}*/
	
	public static synchronized TestPaper getTestPaperById(int testPaperId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		TestPaper tp = new TestPaper();

		String sql = "select * from test_paper where test_paper_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, testPaperId);
			results = statement.executeQuery();

			while (results.next()) {
				tp.setTestPaperId(results.getInt("test_paper_id"));
				tp.setCompanyId(results.getInt("company_id"));
				tp.setTestPaperName(results.getString("test_paper_name"));
				// TODO cd.setEmailSend(results.getBoolean("emailsend"));
				// TODO cd.setTestResult(results.getBoolean("test_send"));
				tp.setQuestions(DBUtils.getQuestionsByTestPaperId(testPaperId));
			}
			
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return tp;
	}
	
	public static synchronized List<TestPaper> getTestPapersByCompanyId(int companyId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<TestPaper> testPaperList = new ArrayList<TestPaper>();
		String sql = "select * from test_paper where company_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, companyId);
			results = statement.executeQuery();

			while (results.next()) {
				TestPaper tp = new TestPaper();

				tp.setTestPaperId(results.getInt("test_paper_id"));
				tp.setCompanyId(results.getInt("company_id"));
				tp.setTestPaperName(results.getString("test_paper_name"));
				// TODO cd.setEmailSend(results.getBoolean("emailsend"));
				// TODO cd.setTestResult(results.getBoolean("test_send"));
				testPaperList.add(tp);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return testPaperList;
	}
	
	/*public static synchronized Question getQuestionByName(String question, int type) {
		PreparedStatement statement = null;
		ResultSet results = null;
		Question questionObj = new Question();
		String sql = "select * from question where obj_question=?";
		if(type == 0) {
			sql = "select * from question where sub_question=?";
		}
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
	
			statement.setString(1, question);
	
			results = statement.executeQuery();

			while (results.next()) {
				questionObj.setAnswer(results.getString("answer"));
				questionObj.setCompanyId(results.getInt("company_id"));
				questionObj.setOption1(results.getString("option1"));
				questionObj.setOption2(results.getString("option2"));
				questionObj.setOption3(results.getString("option3"));
				questionObj.setOption4(results.getString("option4"));
				questionObj.setQuestion(results.getString("obj_question"));
				questionObj.setQuestionId(results.getInt("question_id"));
				questionObj.setQuestionType(results.getInt("question_type"));
				questionObj.setSubjectiveQuestion(results.getString("sub_question"));
				
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return questionObj;
	}*/
	
	public static synchronized Question getQuestionByQuestionId(int questionId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		Question questionObj = new Question();
		String sql = "select * from question where question_id=?";

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
	
			statement.setInt(1, questionId);
	
			results = statement.executeQuery();

			while (results.next()) {
				questionObj.setAnswer(results.getString("answer"));
				questionObj.setCompanyId(results.getInt("company_id"));
				questionObj.setOption1(results.getString("option1"));
				questionObj.setOption2(results.getString("option2"));
				questionObj.setOption3(results.getString("option3"));
				questionObj.setOption4(results.getString("option4"));
				questionObj.setQuestion(results.getString("obj_question"));
				questionObj.setQuestionId(results.getInt("question_id"));
				questionObj.setQuestionType(results.getInt("question_type"));
				questionObj.setSubjectiveQuestion(results.getString("sub_question"));
				questionObj.setCodeQuestion(results.getBoolean("is_file_question"));
				
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return questionObj;
	}
	
	public static synchronized List<Question> getQuestionsByTestPaperId(int testPaperId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<Question> questionsList = new ArrayList<Question>();
		String sql = "select * from test_paper_question where test_paper_id=?";
		
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
	
			statement.setInt(1, testPaperId);
	
			results = statement.executeQuery();

			while (results.next()) {
				int questionId = results.getInt("question_id");
				Question questionObj = DBUtils.getQuestionByQuestionId(questionId);
				questionsList.add(questionObj);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return questionsList;
	}
	
	public static synchronized List<Question> getTestPaperAnwsersByCandidateId(int candidateId, int testPaperId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		List<Question> questionsList = new ArrayList<Question>();
		String sql = "select * from test_paper_answer where test_paper_id=? and candidate_id=?";
		
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
	
			statement.setInt(1, testPaperId);
			statement.setInt(2, candidateId);
			results = statement.executeQuery();

			while (results.next()) {
				int questionId = results.getInt("question_id");
				String candidateAnswer = results.getString("answer");
				Question questionObj = DBUtils.getQuestionByQuestionId(questionId);
				questionObj.setCandidateAnswer(candidateAnswer);
				questionsList.add(questionObj);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return questionsList;
	}
	
	public static synchronized TestAnswer getTestPaperAnwserByQuestionId(int questionId, int testPaperId, int candidateId, int jobId) {
		PreparedStatement statement = null;
		ResultSet results = null;
		String sql = "select * from test_paper_answer where test_paper_id=? and candidate_id=? and opening_id=? and question_id=?";
		TestAnswer answer = new TestAnswer();

		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setInt(1, testPaperId);
			statement.setInt(2, candidateId);
			statement.setInt(3, jobId);
			statement.setInt(4, questionId);
			results = statement.executeQuery();

			while (results.next()) {
				answer.setAnswer(results.getString("answer"));
				answer.setAnswerFile(results.getBinaryStream("code_file"));
				answer.setCandidateId(candidateId);
				answer.setCompanyId(results.getInt("company_id"));
				answer.setOpeningId(jobId);
				answer.setTestPaperId(testPaperId);
			}
		} catch (Exception e) {
			return null;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return answer;
	}
	
	public static synchronized boolean updateCandidateOpeningStatusByCandidateId(int candidateId, int jobId, String status) {
		PreparedStatement statement = null;
		ResultSet results = null;

		String sql = "update candidate_opening set result=? where job_opening_id=? and candidate_id=?";
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			statement.setString(1, status);
			statement.setInt(2, jobId);
			statement.setInt(3, candidateId);
			statement.execute();
		} catch (Exception exe) {
			return false;
		} finally {
			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return true;
	}
	
	
	public static synchronized int getMaxValue(String column, String table) {
		int value = 0;
		PreparedStatement statement = null;
		ResultSet results = null;
		String sql = "select max(" + column + ") from " + table;

		// int value = ThreadLocalRandom.current().nextInt(100, 299);
		try {
			Connection conn = DBConnectionProvider.getConnection();
			statement = conn.prepareStatement(sql);
			results = statement.executeQuery();
			if (results.next()) {
				value = results.getInt(1) + 1;
			}

		} catch (Exception exe) {

		} finally {

			DBConnectionProvider.closeStatementAndResultSet(statement, results);
		}
		return value;
	}

}
