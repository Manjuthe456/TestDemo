package com.jobsonclick.servlets;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.apache.catalina.core.ApplicationPart;

import com.jobsonclick.dao.Candidate;
import com.jobsonclick.dao.CandidateApplication;
import com.jobsonclick.dao.JobOpening;
import com.jobsonclick.dao.Question;
import com.jobsonclick.dao.TestAnswer;
import com.jobsonclick.utils.DBUtils;

@WebServlet(urlPatterns = { "/CandidateHome", "/SearchJobs", "/RegisterCandidate", "/UpdateCandidateProfile",
		"/CandidateViewJob", "/CandidateApplyJob", "/CandidateApplicationHistory" })
@MultipartConfig
public class CandidateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CandidateServlet() {

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession();
		int candidateId = (int) session.getAttribute("candidateId");
		// int candidateId=1;
		if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/CandidateHome")) {
			System.out.println("In CandidateHome");
			Candidate candidate = DBUtils.fetchCandidate(candidateId);
			session.setAttribute("candidate", candidate);

			int applicationCount = DBUtils.fetchAllCandidateApplicationById(candidateId).size();
			int companyCount = DBUtils.fetchAllCompany(true).size();
			int jobCount = DBUtils.fetchAllJobOpening().size();

			session.setAttribute("candidate", candidate);
			request.setAttribute("applicationCount", applicationCount);
			request.setAttribute("companyCount", companyCount);
			request.setAttribute("jobCount", jobCount);

			request.getRequestDispatcher("candidatehomepage.jsp").forward(request, response);
		}

		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/CandidateViewJob")) {
			int jobId = Integer.parseInt(request.getParameter("jobId"));

			JobOpening job = DBUtils.fetchJobOpening(jobId);
			int alreadyApplied = DBUtils.JobApplicationApplied(jobId, candidateId).size();

			request.setAttribute("jobOpening", job);
			request.setAttribute("alreadyApplied", alreadyApplied);

			request.getRequestDispatcher("viewjob.jsp").forward(request, response);
		}

		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/CandidateApplicationHistory")) {

			List<CandidateApplication> applicationList = DBUtils.fetchAllCandidateApplicationById(candidateId);

			request.setAttribute("applicationList", applicationList);

			request.getRequestDispatcher("candidateapplicationhistory.jsp").forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();

		if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/SearchJobs")) {
			boolean jobsList = DBUtils.checkJobOpening(request.getParameter("skills"));
			request.setAttribute("jobsList", jobsList);
			request.setAttribute("skillSearch", request.getParameter("skills"));
			request.getRequestDispatcher("candidatesearchjobs.jsp?searched=true").forward(request, response);
		}

		// RegisterCandidate
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/RegisterCandidate")) {

			// Check if email already exists.
			String email = request.getParameter("candidateEmail");
			// if(Candidate.checkEmailExists(email))
			// {
			// System.out.println("Email already exists." + email);
			// request.setAttribute("message", "Sorry, Email is already registered!");
			// request.getRequestDispatcher("candidateregistration.jsp").forward(request,
			// response);
			// return;
			// }

			try {
				Candidate candidate = new Candidate();
				candidate.setName(request.getParameter("candidateName"));
				candidate.setEmail(request.getParameter("candidateEmail"));
				candidate.setPhoneNo(request.getParameter("candidateContact"));
				candidate.setAddress(request.getParameter("address"));
				candidate.setPassword(request.getParameter("candidatePassword"));
				candidate.setDob(request.getParameter("dob"));
				candidate.setQualification(request.getParameter("qualification"));
				candidate.setYearOfExperience(request.getParameter("candidateExperience"));
				candidate.setSkills(request.getParameter("candidateSkills"));
	//			candidate.setPhoto(getPhotoStream(request));
				candidate.setResume(getResumeStream(request));

				boolean isNotError = DBUtils.createNewCandidate(candidate);

				if (isNotError) {
					request.setAttribute("message", "Candidate Created successfully");
				}
				request.getRequestDispatcher("index.jsp").forward(request, response);
			} catch (Exception exe) {
				request.setAttribute("message", "Error saving photo or resume file. Please try again");
				request.getRequestDispatcher("candidateupdateprofile.jsp").forward(request, response);
			}
		}

		// EditCandidate
		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/UpdateCandidateProfile")) {

			if (session.getAttribute("candidateId") == null) {
				request.setAttribute("message", "Session expired. Please login again");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			Integer candidateId = (Integer) session.getAttribute("candidateId");

			try {
				Candidate candidate = DBUtils.getCandidateById(candidateId);
//				candidate.setName(request.getParameter("candidateName"));
//				candidate.setEmail(request.getParameter("candidateEmail"));
				candidate.setPhoneNo(request.getParameter("candidateContact"));
				candidate.setAddress(request.getParameter("address"));
				candidate.setPassword(request.getParameter("candidatePassword"));
//				candidate.setDob(request.getParameter("dob"));
				candidate.setQualification(request.getParameter("qualification"));
				candidate.setYearOfExperience(request.getParameter("candidateExperience"));
				candidate.setSkills(request.getParameter("candidateSkills"));
//				if (request.getPart("profile") != null) {
//					candidate.setPhoto(getPhotoStream(request));
//				}
				if (request.getPart("resume") != null) {
					candidate.setResume(getResumeStream(request));
				}

				boolean isNotError = DBUtils.updateCandidate(candidate);

				if (isNotError) {
					request.setAttribute("message", "Candidate Updated successfully");
					session.setAttribute("candidate", DBUtils.fetchCandidate(candidateId));
				}
				request.getRequestDispatcher("candidateupdateprofile.jsp").forward(request, response);
			} catch (Exception exe) {
				request.setAttribute("message", "Error saving photo or resume file. Please try again");
				request.getRequestDispatcher("candidateupdateprofile.jsp").forward(request, response);
			}
		}

		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/CandidateApplyJob")) {
			int jobId = Integer.parseInt(request.getParameter("jobId"));
			if (session.getAttribute("candidateId") == null) {
				request.setAttribute("message", "Session expired. Please login again");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			Integer candidateId = (Integer) session.getAttribute("candidateId");

			int testPaperId = DBUtils.getJob(jobId).getTestPaperId();
			List<Question> questions = DBUtils.getTestPaperById(testPaperId).getQuestions();
			
			for (Question question : questions) {
				String answer = request.getParameter("answer" + question.getQuestionId());

				TestAnswer testAnswer = new TestAnswer();
				testAnswer.setAnswer(answer);
				testAnswer.setCandidateId(candidateId);
				testAnswer.setCompanyId(question.getCompanyId());
				testAnswer.setQuestionId(question.getQuestionId());
				testAnswer.setTestPaperId(testPaperId);
				testAnswer.setOpeningId(jobId);
				try {
				if(request.getParameter("codeQuestion"+ question.getQuestionId()) != null) {

					testAnswer.setAnswerFile(getCodeFileStream(request, "codeFile" + question.getQuestionId()));

				}
					
				DBUtils.submitTestPaperQuestionAnswer(testAnswer);
				} catch(Exception exe) {
					exe.printStackTrace();
				}

			}
			boolean isNotError = DBUtils.insertCandidateJobApplication(jobId, candidateId);

			if (isNotError) {
				request.setAttribute("message", "Job Applied successfully!");
			} else {
				request.setAttribute("message", "Error applying for Job application. Please try again!");
			}
			request.setAttribute("alreadyApplied", 1);
			request.getRequestDispatcher("/CandidateViewJob").forward(request, response);
		}

		// ***************************************Get calls
		// **********************************************************

		else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/CandidateViewJob")) {
			doGet(request, response);
		} else if (request.getRequestURI().equalsIgnoreCase("/JobsOnClick/CandidateHome")) {
			doGet(request, response);
		}
	}

//	private byte[] getPhoto(HttpServletRequest request) throws Exception {
//		Part filePartProfile = request.getPart("profile");
//		int docLength1 = (int) filePartProfile.getSize();
//		InputStream inputProfile = filePartProfile.getInputStream();
//		ByteArrayOutputStream profileOutput = new ByteArrayOutputStream();
//		byte[] bufferProfile = new byte[docLength1 * 1024];
//		System.out.println("profile length:---------" + docLength1);
//		for (int length = 0; (length = inputProfile.read(bufferProfile)) > 0;)
//			profileOutput.write(bufferProfile, 0, length);
//		// ************ Set as output.toByteArray()***************
//		return profileOutput.toByteArray();
//	}

//	private InputStream getPhotoStream(HttpServletRequest request) throws Exception {
//		Part filePartProfile = request.getPart("profile");
//		int docLength1 = (int) filePartProfile.getSize();
//		InputStream inputProfile = filePartProfile.getInputStream();
//
//		return inputProfile;
//	}

	private byte[] getResume(HttpServletRequest request) throws Exception {
		Part filePartProfile = request.getPart("resume");
		int docLength1 = (int) filePartProfile.getSize();
		InputStream inputProfile = filePartProfile.getInputStream();
		ByteArrayOutputStream profileOutput = new ByteArrayOutputStream();
		byte[] bufferProfile = new byte[docLength1 * 1024];
		System.out.println("profile length:---------" + docLength1);
		for (int length = 0; (length = inputProfile.read(bufferProfile)) > 0;)
			profileOutput.write(bufferProfile, 0, length);
		// ************ Set as output.toByteArray()***************
		return profileOutput.toByteArray();
	}

	private InputStream getResumeStream(HttpServletRequest request) throws Exception {
		Part filePartProfile = request.getPart("resume");
		int docLength1 = (int) filePartProfile.getSize();
		InputStream inputProfile = filePartProfile.getInputStream();

		return inputProfile;
	}

	private InputStream getCodeFileStream(HttpServletRequest request, String codeFileAttribute) throws Exception {
		Part filePartProfile = request.getPart(codeFileAttribute);
		int docLength1 = (int) filePartProfile.getSize();
		InputStream inputProfile = filePartProfile.getInputStream();

		return inputProfile;
	}

}
