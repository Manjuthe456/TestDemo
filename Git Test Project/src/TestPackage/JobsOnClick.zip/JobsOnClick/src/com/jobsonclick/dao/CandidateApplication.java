package com.jobsonclick.dao;

public class CandidateApplication {
	private int candidateOpeningId;
	private int jobOpeningId;
	private int candidateId;
	private String result;
	/**
	 * Applied
	 * OnHold
	 * Selected
	 * Rejected
	 */
	private String status;
	public int getCandidateOpeningId() {
		return candidateOpeningId;
	}
	public void setCandidateOpeningId(int candidateOpeningId) {
		this.candidateOpeningId = candidateOpeningId;
	}
	public int getJobOpeningId() {
		return jobOpeningId;
	}
	public void setJobOpeningId(int jobOpeningId) {
		this.jobOpeningId = jobOpeningId;
	}
	public int getCandidateId() {
		return candidateId;
	}
	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}

	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	 

	

}
