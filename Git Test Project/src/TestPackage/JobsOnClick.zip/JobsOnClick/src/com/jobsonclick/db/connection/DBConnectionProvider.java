package com.jobsonclick.db.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnectionProvider {
	
	private static Connection conn = null;
	
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
		} catch(Exception exe) {
			System.out.println("RegisterDriver error : " + exe.getMessage());
			exe.printStackTrace();
		}
	}
	public static Connection getConnection() throws Exception{
		String jdbcString = "jdbc:mysql://jobsonclickdb.c36bjauostww.us-east-1.rds.amazonaws.com:3306/jobsonclick";
	//	String jdbcString = "jdbc:mysql://localhost:3306/jobsonclick";
		String userName = "root";
		String password = "Jobsonclick123";
	//	String password = "root";
		
	//	String jdbcString = "jdbc:mysql://jobsonclickdb.cnrxz90gsjit.ap-southeast-2.rds.amazonaws.com:3306/jobsonclick";
	//	String password = "Jobsonclick123";
		
		try {
			if (conn == null || conn.isClosed()) {
				
				conn = (Connection) DriverManager.getConnection(jdbcString, userName, password);
			}
		}catch (Exception e) {
			System.out.println("JDBC String: " + jdbcString);
			System.out.println("user Name: " + userName);
			System.out.println("password: " + password);
			System.out.println(" database error:" + e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return conn;
	}
	public static void closeConnection() {
		if (conn != null) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	public static void closeStatementAndResultSet(Statement statement, ResultSet resultset) {
		try {
			if(statement != null) {
				statement.close();
			}
			if(resultset != null) {
				resultset.close();
			}
		}catch(Exception exe) {
			System.out.println("Error while closing statement and resultset");
			exe.printStackTrace();
		}
	}
	

}
