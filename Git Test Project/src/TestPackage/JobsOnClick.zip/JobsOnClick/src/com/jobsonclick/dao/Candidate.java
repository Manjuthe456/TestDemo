package com.jobsonclick.dao;

import java.io.InputStream;

public class Candidate {
 private int candidateId;
 private String name;
 private String phoneNo;
 private String email;
 private String address;
 private String gender;
 private String dob;
 private String password;
 private String skills;
 private String qualification;
 private String yearOfExperience;
 private InputStream photo;
 private InputStream resume;
 private int status;
public int getCandidateId() {
	return candidateId;
}
public void setCandidateId(int candidate_id) {
	this.candidateId = candidate_id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getQualification() {
	return qualification;
}
public void setQualification(String qualification) {
	this.qualification = qualification;
}
public String getYearOfExperience() {
	return yearOfExperience;
}
public void setYearOfExperience(String yearOfExperience) {
	this.yearOfExperience = yearOfExperience;
}
public InputStream getPhoto() {
	return photo;
}
public void setPhoto(InputStream photo) {
	this.photo = photo;
}
public InputStream getResume() {
	return resume;
}
public void setResume(InputStream resume) {
	this.resume = resume;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getPhoneNo() {
	return phoneNo;
}
public String getSkills() {
	return skills;
}
public void setSkills(String skills) {
	this.skills = skills;
}
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
 
}