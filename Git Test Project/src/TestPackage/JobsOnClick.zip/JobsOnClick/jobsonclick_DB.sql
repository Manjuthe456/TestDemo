CREATE DATABASE IF NOT EXISTS jobsonclick;
USE jobsonclick;

DROP TABLE IF EXISTS admin;
CREATE TABLE admin (
username varchar(50)NOT NULL,
password varchar(50)NOT NULL
);

insert into admin(username,password)values("admin","admin");

DROP TABLE IF EXISTS candidate;

CREATE TABLE candidate(
candidate_id INT PRIMARY KEY AUTO_INCREMENT,
name VARCHAR(100) NOT NULL,
phone_no VARCHAR(50),
email VARCHAR(100) NOT NULL,
address VARCHAR(200),
gender VARCHAR(50),
skills VARCHAR(100),
dob VARCHAR(50),
password VARCHAR(100),
qualification VARCHAR(100),
year_of_experience VARCHAR(50),
status INT,
photo longblob DEFAULT NULL,
resume longblob DEFAULT NULL
);
 

DROP TABLE IF EXISTS company;

CREATE TABLE company(
company_id INT PRIMARY KEY AUTO_INCREMENT,
name VARCHAR(100) NOT NULL,
address VARCHAR(200) NOT NULL,
email VARCHAR(80) NOT NULL,
phone_no VARCHAR(20) NOT NULL,
hr_name VARCHAR(50),
hr_email VARCHAR(80),
password VARCHAR(80) NOT NULL,
description VARCHAR(80),
status INT
);

DROP TABLE IF EXISTS job_opening;

CREATE TABLE job_opening(
job_opening_id INT PRIMARY KEY AUTO_INCREMENT,
company_id INT NOT NULL,
job_exp VARCHAR (100),
job_requirement VARCHAR(100),
location VARCHAR(100),
mode VARCHAR(100),
status VARCHAR(100),
salary VARCHAR(100),
job_title VARCHAR(100),
test_paper_id INT
);

DROP TABLE IF EXISTS candidate_opening;

CREATE TABLE candidate_opening(
candidate_opening_id INT PRIMARY KEY AUTO_INCREMENT,
job_opening_id INT NOT NULL,
candidate_id INT NOT NULL,
result VARCHAR(50),
status VARCHAR(50),
FOREIGN KEY (job_opening_id) REFERENCES job_opening(job_opening_id)
);

DROP TABLE IF EXISTS test_paper;

CREATE TABLE test_paper(
test_paper_id INT PRIMARY KEY,
company_id INT NOT NULL,
test_paper_name VARCHAR(100)
);

DROP TABLE IF EXISTS question;

CREATE TABLE question(
question_id INT PRIMARY KEY,
question_type INT NOT NULL,
company_id INT NOT NULL,
obj_question VARCHAR (200),
option1 VARCHAR (100),
option2 VARCHAR (100),
option3 VARCHAR (100),
option4 VARCHAR (100),
answer  VARCHAR (800), 
sub_question VARCHAR (200),
is_file_question BOOLEAN
);


DROP TABLE IF EXISTS test_questions;

CREATE TABLE test_paper_question(
test_paper_id INT NOT NULL,
question_id INT NOT NULL,
company_id INT NOT NULL

);

DROP TABLE IF EXISTS test_questions;

CREATE TABLE test_paper_answer(
test_paper_id INT NOT NULL,
question_id INT NOT NULL,
company_id INT NOT NULL,
candidate_id INT NOT NULL,
opening_id INT NOT NULL,
answer VARCHAR(500),
code_file longblob DEFAULT NULL

);

